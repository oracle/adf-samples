drop package dept_service;
@@CreateDeptEmpTables
@@DepartmentTypes
@@DepartmentService
@@DepartmentServiceBody