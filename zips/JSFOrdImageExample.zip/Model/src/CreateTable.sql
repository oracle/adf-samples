drop table image_table;
create table image_table( id number primary key,
                          description varchar2(40),
                          image ordimage);
