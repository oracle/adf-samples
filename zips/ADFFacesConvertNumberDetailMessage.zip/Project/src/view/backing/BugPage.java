/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package view.backing;

import java.util.Map;

public class BugPage {
    int field2;
    int field3; 
        
    
    
    public BugPage() {
    }

    public String commandButton_action() {
        // Add event code here...
        return null;
    }

    public void setField2(int field2) {
        this.field2 = field2;
    }

    public int getField2() {
        return field2;
    }

    public void setField3(int field3) {
        this.field3 = field3;
    }

    public int getField3() {
        return field3;
    }
}
