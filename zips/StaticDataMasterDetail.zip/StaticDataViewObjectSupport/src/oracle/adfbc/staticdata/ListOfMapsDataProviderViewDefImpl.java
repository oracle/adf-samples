/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package oracle.adfbc.staticdata;

import oracle.jbo.AttributeDef;
import oracle.jbo.server.ViewDefImpl;

public class ListOfMapsDataProviderViewDefImpl extends ViewDefImpl {
    public ListOfMapsDataProviderViewDefImpl() {
    }

//    @Override
//    protected void finishedLoading() {
//        super.finishedLoading();
//        for (Attribut
//            eDef attrDef : getAttributeDefImpls())
//    }
}
