/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.model.fwkext;

import oracle.jbo.server.ViewRowImpl;

public class CustomViewRowImpl extends ViewRowImpl {
  /*
   * Custom view row logic goes here
   */
}
