/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.view;

public class PPRDemo {
  int counter;
  public int getCounter() {
    return ++counter;
  }
}
