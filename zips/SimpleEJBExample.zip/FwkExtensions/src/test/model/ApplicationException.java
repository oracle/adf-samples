/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.model;

public class ApplicationException {
  public ApplicationException() {
  }
}
