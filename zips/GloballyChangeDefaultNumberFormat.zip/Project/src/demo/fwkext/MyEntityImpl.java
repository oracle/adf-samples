/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package demo.fwkext;
import oracle.jbo.server.EntityImpl;

public class MyEntityImpl extends EntityImpl 
{
  public MyEntityImpl()
  {
  }
}
