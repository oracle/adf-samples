/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package demo.controller;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.lifecycle.PageController;
public class PageLoadExamplePageController extends PageController {
  public PageLoadExamplePageController() {
  }
  public void prepareModel(LifecycleContext context) {
    super.prepareModel(context);
  }
}
