/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package viewjsfrich.backing;
import java.io.IOException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class AnotherPage extends BackingBeanBase {
    // Other backing bean methods for Main page would go here

}
