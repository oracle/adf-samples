create type table_of_varchar as table of varchar2(80);
.
/
