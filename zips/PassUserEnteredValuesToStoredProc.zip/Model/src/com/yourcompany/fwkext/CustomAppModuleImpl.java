/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package com.yourcompany.fwkext;
import oracle.jbo.server.ApplicationModuleImpl;
public class CustomAppModuleImpl extends ApplicationModuleImpl {
}
