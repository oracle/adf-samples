var LocaleSymbols_es_BO = new LocaleSymbols({
MonthNames:["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], 
MonthAbbreviations:["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"], 
DayNames:["Domingo", "Lunes", "Martes", "Mi\xe9rcoles", "Jueves", "Viernes", "S\xe1bado"], 
DayAbbreviations:["Dom", "Lun", "Mar", "Mi\xe9", "Jue", "Vie", "S\xe1b"], 
AmPmMarkers:["AM", "PM"], 
Eras:["AC", "DC"], 
DateTimePatterns:["hh:mm:ss a z", "hh:mm:ss a z", "hh:mm:ss a", "hh:mm a", "EEEE d\x27 de \x27MMMM\x27 de \x27yyyy", "d\x27 de \x27MMMM\x27 de \x27yyyy", "dd-MM-yyyy", "dd-MM-yy", "{1} {0}"], 
DateTimeElements:["2", "1"], 
NumberElements:[".", ",", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"]
});
