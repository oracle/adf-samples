/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.model.fwkext;

import oracle.jbo.server.DBTransactionImpl2;

public class CustomDBTransactionImpl extends DBTransactionImpl2 {
  /*
   * Custom database transaction logic goes here
   */
}
