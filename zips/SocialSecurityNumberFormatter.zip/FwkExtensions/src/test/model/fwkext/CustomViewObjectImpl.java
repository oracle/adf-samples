/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.model.fwkext;

import oracle.jbo.server.ViewObjectImpl;

public class CustomViewObjectImpl extends ViewObjectImpl {
  /*
   * Custom view object logic goes here
   */
}
