/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.model.fwkext;

import oracle.jbo.server.ApplicationModuleImpl;

public class CustomApplicationModuleImpl extends ApplicationModuleImpl {
  /*
   * Custom application module logic goes here
   */
}
