/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.view;

public class MyBean {
    public MyBean() {
        super();
    }
  public void myMethod(String arg1) {
    System.out.println(arg1);
  }    
    public String getSomething() {
      return "Something";
    }
}
