/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package test.view;

public class UserInfo {
    String favoriteColor;


    public void setFavoriteColor(String favoriteColor) {
        this.favoriteColor = favoriteColor;
    }

    public String getFavoriteColor() {
        return favoriteColor;
    }
}
