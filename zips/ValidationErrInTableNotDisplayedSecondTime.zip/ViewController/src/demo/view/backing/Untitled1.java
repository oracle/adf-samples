/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package demo.view.backing;
import oracle.adf.view.faces.event.RangeChangeEvent;
public class Untitled1 {
  public Untitled1() {
  }
  public void onTableRangeChanged(RangeChangeEvent rangeChangeEvent) {
    // System.out.println("###");
  }
}
