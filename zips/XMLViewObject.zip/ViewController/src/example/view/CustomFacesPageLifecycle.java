/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package example.view;
import oracle.adf.controller.faces.lifecycle.FacesPageLifecycle;
import oracle.adf.controller.v2.context.LifecycleContext;

import oracle.jbo.ApplicationModule;
public class CustomFacesPageLifecycle extends FacesPageLifecycle {
  public CustomFacesPageLifecycle() {
  }

}
