/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package example.model;

public class MyService  {
  public MyService() {
  }
  public void sayHello(String name) {
    System.out.println("Hello, "+name);
  }
}
