/* Copyright 2010, 2017, Oracle and/or its affiliates. All rights reserved. */
package example.model;
public class MyBean {
    String name;
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
